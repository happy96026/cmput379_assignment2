#ifndef ERROR_HANDLING_H_
#define ERROR_HANDLING_H_

void FATAL(const char *fmt, ...); 
void WARNING(const char *fmt, ...); 

#endif
